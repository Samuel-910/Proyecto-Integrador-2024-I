package com.example.msauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
